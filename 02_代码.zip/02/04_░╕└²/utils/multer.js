const multer = require('multer')
const path = require('path')

// 配置仓库信息
const storage = multer.diskStorage({
  // 指定存储目录
  destination (req, file, cb) {
    cb(null, path.join(__dirname, '../', 'public', 'avatar'))
  },
  // 重新设定文件名
  filename (req, file, cb) {
    const extname = path.extname(file.originalname)
    cb(null, `avatar-${ new Date().getTime() }${ extname }`)
  }
})

// 生成一个接收器
const avatar = multer({ storage })

exports.avatar = avatar
