// 正则验证文件
const email = /^[0-9a-zA-Z]\w{5,11}@(qq|sina|163)\.(com|cn)$/
const passowrd = /^\w{6,12}$/
const phone = /^\d{11}$/
const gender = /^(男|女|保密)$/

// 验证邮箱的正则
exports.testEmail = (function (reg) {
  return function (val) {
    return reg.test(val)
  }
})(email)

// 验证密码的正则
exports.testpwd = (function (reg) {
  return function (val) {
    return reg.test(val)
  }
})(passowrd)

// 验证手机号的正则
exports.testPhone = (function (reg) {
  return function (val) {
    return reg.test(val)
  }
})(phone)

// 验证性别的正则
exports.testGender = (function (reg) {
  return function (val) {
    return reg.test(val)
  }
})(gender)
