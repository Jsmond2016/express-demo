const session = require('express-session')
const MongoStore = require('connect-mongo')(session)

module.exports = function () {
  return session({
    secret: 'guoxiang',
    name: 'sessid',
    resave: true,
    saveUninitialized: true,
    cookie: { maxAge: 1000 * 60 * 10 },
    store: new MongoStore({
      url: 'mongodb://localhost:27017/gp19'
    })
  })
}
