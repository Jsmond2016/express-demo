const router = require('express').Router()

// 导入正则验证工具库
const { testEmail, testpwd, testPhone, testGender } = require('../utils/reg')

// 导入数据库模型
const { UserModel } = require('../db/db')

// 导入文件接收器
const { avatar } = require('../utils/multer')

// 配置路由表

// 1. 登录
router.post('/login', async (req, res) => {
  // 接收请求体
  console.log(req.body)
  const { email, password } = req.body

  // 1-1. 参数验证
  if (!email || !password) return res.send({ message: '请完整填写表单!', code: 0 })

  // 1-2. 表单格式验证
  if (!testEmail(email) || !testpwd(password)) return res.send({ message: '按照规则填写表单!', code: 0 })

  // 1-3. 去数据库操作
  const result = await UserModel.findOne({ email, password })

  // 1-4. 根据结果给出信息
  if (!result) return res.send({ message: "用户名密码错误!", code: 0 })

  // 表示登录成功
  // 存储一个标识符, 直接把用户信息存储进去
  req.session.userInfo = result

  // 给出正确的响应
  res.send({ message: '登录成功', code: 1 })
})

// 2. 修改个人信息
router.post('/update', avatar.single('avatar'), async (req, res) => {
  const { file: { filename }, body: { phone, age, desc, hobby, gender } } = req
  // 参数验证
  if (!testPhone(phone) || desc.length > 200 || !testGender(gender)) return res.send({ message: '修改失败, 参数有问题!', code: 0 })

  // 将来要修改的信息
  const userInfo = {
    avatar: '/public/avatar/' + filename,
    phone,
    age,
    desc,
    gender,
    hobby: hobby.split(',')
  }

  // 使用方法去修改
  UserModel
    .updateOne({ _id: req.session.userInfo._id }, userInfo)
    .then(() => {
      res.send({ message: '修改成功', code: 1 })
    })
    .catch(err => console.log(err))




})


// 导出路由表
module.exports = router
