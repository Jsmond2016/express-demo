const express = require('express')
// 导入页面路由表
const viewsRouter = require('./routes/views')
// 导入 user 路由表
const usersRouter = require('./routes/users')
// 导入 mongodb 数据库连接
const { Mongo } = require('./db/db')
// 导入 session 配置
const session = require('./utils/session.js')

// 创建服务
const app = express()

// 引擎挂载 art-template
app.engine('html', require('express-art-template'))

// 挂载静态资源
// 用到静态路径最好是写一个绝对路径
app.use('/public', express.static(__dirname + '/public'))
app.use('/node_modules', express.static(__dirname + '/node_modules'))

// 挂载解析请求体
//   只要是请求都会给你解析
//   静态资源没有必要解析
app.use(express.urlencoded())

// 挂载 session 配置
app.use(session())

// 挂载页面路由表
app.use('/views', viewsRouter)
// 挂载 user 路由表
app.use('/users', usersRouter)

// 连接数据库
Mongo.connect()

// 监听端口
app.listen(8080, () => console.log('express server running at port 8080 ! @-@ '))
