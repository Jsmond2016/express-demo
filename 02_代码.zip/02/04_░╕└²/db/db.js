const mongoose = require('mongoose')

const Mongo = {
  connect: function () {
    mongoose.connect('mongodb://localhost:27017/gp19', err => {
      if (err) return console.log(err)

      console.log('连接数据库成功 ! ^_^ ')
    })
  }
}

// 用户结构
const user = new mongoose.Schema({
  email: { type: String, required: true },
  password: { type: String, required: true, minlength: 6, maxlength: 12 },
  age: { type: Number, default: 0 },
  gender: { type: String, enum: [ '男', '女', '保密' ], default: '保密' },
  phone: { type: String, minlength: 11, maxlength: 11 },
  desc: { type: String, maxlength: 200 },
  avatar: { type: String, default: '/public/images/default_avatar.jpg' },
  createTime: { type: Date, default: Date.now() },
  hobby: { type: Array }
})

// 创建模型
const UserModel = mongoose.model('users', user)

module.exports = {
  Mongo,
  UserModel
}
