const form = document.querySelector('form')
const nameInp = document.querySelector('input[name=username]')
const pwdInp = document.querySelector('input[name=password]')


form.addEventListener('submit', function (e) {
  e.preventDefault()

  const username = nameInp.value
  const password = pwdInp.value

  // 表单验证
  if (!username || !password) return window.alert('请完整填写表单')

  // 发送请求
  const xhr = new XMLHttpRequest()

  xhr.open('POST', '/users/login')

  xhr.onload = function () {
    const { message, code } = JSON.parse(xhr.responseText)

    if (code === 0) return window.alert(message)

    window.location.href = './index.html'
  }

  xhr.setRequestHeader('content-type', 'application/x-www-form-urlencoded')

  xhr.send(`email=${ username }&password=${ password }`)
})
