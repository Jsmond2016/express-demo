const router = require('express').Router()
const fs = require('fs')

router.get('/index.html', (req, res) => {
  fs.readFile('./views/index.html', 'utf8', (err, data) => {
    if (err) return console.log(err)

    // 需要获取 cookie
    // req.cookies 得到一个对象 {}
    //   里面是所有的 cookie 信息
    // 没有 cookie 的时候得到什么 ? {}
    console.log(req.cookies)

    // 设置 cookie
    // 使用 res.cookie()
    //   语法: res.cookie(key, value, options)
    //   options 里面配置 路径 域名 过期时间
    // res.cookie('c', 300) // 默认会话级别过期时间
    //   maxAge 表示过期时间, 按照 毫秒 计算
    res.cookie('c', 300, { maxAge: 1000 * 10 })

    res.send(data)
  })
})


module.exports = router
