/*
  cookie-parser 的使用
    + 专门操作 cookie 的插件

  1. 下载
    + npm i cookie-parser
  2. 导入
    + require()
  3. 挂载到服务上
    3-1. 会在 req 上添加一个叫做 cookies 的成员
      => 里面是所有的 cookie 信息
    3-2. 会在 res 上添加一个叫做 cookie 的方法
      => 设置 cookie 的时候使用的方法
    + 注意: 挂载在路由的前面
  4. 使用
    + 如果你要获取 cookie, 就是用 req.cookies
    + 如果你要设置 cookie, 就是用 res.cookie()
*/

const express = require('express')
const router = require('./routes/router')

// 2. 导入 cookie-parser
const cookieParser = require('cookie-parser')

const app = express()

// 3. 挂载到服务上
app.use(cookieParser())

app.use(router)

app.listen(8080, () => console.log('runnging at port 8080 ! ^_^'))
