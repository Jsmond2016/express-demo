/*
  express-art-template 插件
    + 专门和 express 结合, 的 art-template 模板引擎

  1. 下载
    => npm i express-art-template
    => npm i art-template
  2. 配置
    => 不是简单的挂载, 而是配置在服务的引擎上
    => 语法: app.engine(后缀名, 在引擎上配置哪个内容)
  3. 使用
    => 当你在引擎上配置好以后, express-art-template
    => 会在 res 上添加一个方法, 叫做 render()
      + 语法: res.render(路径, 对象)
        -> 路径, 默认是服务器根目录(app.js 所在目录)下的 views 文件夹里面的路径
           a.html   ->   views/a.html
           会自动读取这个匹配的文件
        -> 对象: 成员, 就是在指定文件里面使用的数据
           { name: 'Jack' }
      + 作用:
        1. 自动取 views 文件夹里面按照你的路径读取文件
        2. 自动按照 模板引擎 组装好你的页面
        3. 自动把这个拼接好的页面返回给前端

  问题: 我的页面不一定非得在 views
    => 但是 express-art-template 自动读取 views
  解决: 修改一下默认目录
    => 我文件放在哪个目录里面就修改成那一个目录
    => app.set(要修改哪个内容, 修改成什么)
      -> 如果你要写目录, 尽量时绝对路径
*/

const express = require('express')
const router = require('./routes/router')
const cookieParser = require('cookie-parser')
const session = require('express-session')
const app = express()

// 1. 在服务引擎上配置 art-template
//    这里导入的 express-art-template 会自动导入 art-template
app.engine('html', require('express-art-template'))
// 设置 express-art-template 的默认读取目录
app.set('views', __dirname + '/pages')

app.use(session({
  secret: 'guoxiang',
  name: 'sessid',
  cookie: { maxAge: 1000 * 10 },
  resave: true,
  saveUninitialized: true
}))

app.use(cookieParser())

app.use(router)

app.listen(8080, () => console.log('runnging at port 8080 ! ^_^'))
