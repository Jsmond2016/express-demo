const router = require('express').Router()

router
  .get('/index.html', (req, res) => {
    // 根据 session 里面有没有指定成员来决定是不是渲染页面
    if (!req.session.nickname) return res.redirect('/login.html')

    // 1. 读取页面
    // 2. 组装页面
    // 3. 返回页面
    res.render('./a/index.html', { nickname: req.session.nickname })
  })
  .get('/login.html', (req, res) => {
    // 需要把登录页面给到前端
    // 1. fs
    // 2. send()
    req.session.nickname = '郭翔'
    res.render('./login.html', {})
  })


module.exports = router
