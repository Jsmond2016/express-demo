const router = require('express').Router()
const fs = require('fs')
const template = require('art-template')

router
  .get('/index.html', (req, res) => {
    // 1. 自己读取指定目录下的指定
    fs.readFile('./views/index.html', 'utf8', (err, data) => {
      if (err) return console.log(err)

      // 访问 session 空间
      // 里面如果有这个信息, 表示登陆过, 我就给你正常显示页面
      // 如果没有我之前存储的信息, 表示没有登录, 或者 一半 session id 时假的
      // 直接跳转回登录页
      // 在这里的 req.session.nickname 如果是 undefined, 回到 login
      //  req.session.nickname === '郭翔' 表示登陆过
      // console.log(req.session)
      // 登录验证的判断
      // express 对于 res 添加了一个方法叫做 res.redirect()
      console.log(req.session)
      if (!req.session.nickname) return res.redirect('/login.html')

      // 2. 自己使用 art-template 去组装页面
      const html = template.render(data, { nickname: req.session.nickname })

      // 3. 自己手动把结果返回给前端
      res.send(html)
    })
  })
  .get('/login.html', (req, res) => {
    fs.readFile('./views/login.html', 'utf8', (err, data) => {
      if (err) return console.log(err)

      // 打开页面就默认登录成功了
      // 默认登录成功
      // 在 session 空间里面存储一个数据, 表示我登录成功了
      // 如果你需要存储, req.session.名字 = 值
      req.session.nickname = '郭翔'

      res.send(data)
    })
  })


module.exports = router
