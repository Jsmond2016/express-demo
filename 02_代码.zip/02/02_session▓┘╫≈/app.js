/*
  express-session 的插件
    + 专门和 express 框架结合生成一个 session 空间

  1. 下载
    + npm i express-session
  2. 导入
  3. 挂载在 服务 上
    + express-session 会操作 cookie, 而且是自动操作 cookie
    + app.use(session({ 对 session 空间的配置 }))
      => secret: 加密口令 guoxiang
      => saveUninitialized: 未初始化的时候需要不需要存储内容, 默认是 true
      => resave: 重新存储, 一半开成 true, 表示每一次 session 修改的时候都会从新存储
      => name: 设置 cookie 的 key
      => cookie: 设置 cookie 的 存储配置
  4. 使用
    + 会在 req 上添加一个成员叫做 session
    + 是一个对象空间, 我们可以向里面添加一些成员内容
    + 当你第一次存储内容的时候, 就已经把内容存进去了
      => express-session 插件会自动生成一个 session id
      => 自动把这个 id 分成两半, 一半放在 cookie 里面, 一半放在 服务器的 内存

  问题: 属于服务器的一半 session id 时存储在内存中
    => 一旦服务器重启, 数据消失了
  解决: 持久化存储
    => 存在数据库里面
    => express-session 有一个配置项叫做 store
    => 依赖一个第三方插件 connect-mongo

  connect-mongo
    1. 下载: npm i connect-mongo
    2. 导入: require()
    3. 配置:
      3-1. 使用 connectMongo 和 session 关联
      3-2. 在配置 session 的时候配置使用
        => 在 session 的挂载配置里面添加一个
        => store: new MongoStore({
          url: '', 存储位置
          touchAfter: 1000 * 10, 自动延长过期时间(不推荐设置, 最少建议设置成一天)
        })
        => 过期以后会自动删除
*/

const express = require('express')
const router = require('./routes/router')
const cookieParser = require('cookie-parser')
// 2. 导入 express-session
const session = require('express-session')

// 导入 connect-mongo
// const connectMongo = require('connect-mongo')
// 和 session 关联
// const MongoStore = connectMongo(session)
const MongoStore = require('connect-mongo')(session)

const app = express()

// 3. 挂载 session
app.use(session({ // 进行各种配置
  secret: 'guoxiang',
  name: 'sessid',
  cookie: { maxAge: 1000 * 10 },
  resave: true,
  saveUninitialized: true,
  store: new MongoStore({
    // 你存储到 mongodb 的那一个位置
    url: 'mongodb://localhost:27017/gp19'
  })
}))

app.use(cookieParser())

app.use(router)

app.listen(8080, () => console.log('runnging at port 8080 ! ^_^'))
