/*
  单文件上传的复杂版本

    1. 解决跨域问题
      + 下载一个包叫做 cors
    2. 接收文件
      2-1. 我要准备一个文件夹, 在服务器上
        => 存储上传的文件
      2-2. 需要一个插件帮助
        => multer
        => 下载
        => 导入
      2-3. 生成一个仓库信息
        => multer.diskDtorage({ 配置 })
          -> destitnation: function () {}  设定存储路径
          -> filename: function () {}  设定文件名称
        => 返回值: 是一个仓库信息
      2-4. 使用 multer 生成一个接收器
        => 接收器里面配置一个仓库信息
        => 语法: multer({ storage: 仓库信息 })

*/

const express = require('express')
const path = require('path')
const router = express.Router()
// 1. 导入 cors 插件
const cors = require('cors')

// 2-2. 导入 multer 插件
const multer = require('multer')

// 2-3. 使用 multer 生成一个仓库信息
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // req, 本次请求信息
    // file, 本次请求的文件
    // cb, 回调函数, 利用回调函数来设定存储路径
    // 第一个参数 null, 表示不要修改我的 二进制流 文件
    cb(null, '../uploads/')
  },
  filename: function (req, file, cb) {
    // req, 本次请求信息
    // file, 本次上传的文件信息
    // cb, 回调函数, 通过回调函数来设定文件名称
    // 从 file 信息里面把后缀名拿出来, 前面我们自己拼接随机数
    const tmp = path.extname(file.originalname)
    cb(null, `avatar_${ new Date().getTime() }-${ Math.random().toString().slice(2) }${ tmp }`)
  }
})

// 2-4. 配置接收器, 带有仓库信息
const fileUpload = multer({ storage })

const app = express()

// 1. 挂载上 cors 就跨域了
app.use(cors())

// 2-5. 使用我们配置好的接收其去接收文件
router.post('/upload', fileUpload.single('avatar'), (req, res) => {
  console.log('接收请求')
  console.log(req.file)
})

app.use(router)

app.listen(8080, () => console.log(8080))
