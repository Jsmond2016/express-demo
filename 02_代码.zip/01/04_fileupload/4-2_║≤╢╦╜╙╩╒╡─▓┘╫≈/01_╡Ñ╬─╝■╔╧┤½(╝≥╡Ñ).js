/*
  单文件上传的简单版本

    1. 解决跨域问题
      + 下载一个包叫做 cors
    2. 接收文件
      2-1. 我要准备一个文件夹, 在服务器上
        => 存储上传的文件
      2-2. 需要一个插件帮助
        => multer
        => 下载
        => 导入
      2-3. 需要使用 multer 配置一个接收器
        => multer({ dest: '你存放文件的路径' })
      2-4. 使用接收器去接收文件
        => 哪一个路由需要接收文件, 配置在哪一个路由上
        => 写在路由标识符的后面, 路由处理函数的前面
        => 接收器.single('前端上传的文件的 key')
      2-5. 在路由处理函数里面
        => 会在 req 上面多家一个信息叫做 file
        => 就是你上传的文件的信息
      注意: 会把你的文件存储起来, 但是没有后缀, 随机命名
*/

const express = require('express')
const router = express.Router()
// 1. 导入 cors 插件
const cors = require('cors')

// 2-2. 导入 multer 插件
const multer = require('multer')

// 2-3. 使用 multer 去生成一个接收其
//      我配置的这个接收器, 将来接收到的文件就直接存储在 指定目录
const fileUpload = multer({ dest: '../uploads/' })

const app = express()

// 1. 挂载上 cors 就跨域了
app.use(cors())

// 2-4. 在需要的路由上进行配置
router.post('/upload', fileUpload.single('avatar'), (req, res) => {
  console.log('接收请求')
  console.log(req.file)
})

app.use(router)

app.listen(8080, () => console.log(8080))
