alert('hello world')
