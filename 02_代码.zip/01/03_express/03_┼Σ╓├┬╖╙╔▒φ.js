/*
  后端路由
    + 路由: 根据前端的不同请求给出不同个响应
    + 我们在处理业务逻辑的时候, 我们就可以把所有的请求分类方好
    + express 最初实现路由就是 app.get() app.post() ...

  express 的路由表
    + express 框架单独给我们出现的 API
    + 不进行路由的处理, 只是但如配置一张表
    + 把配置好的表, 交给服务, 让服务按照这个表的配置进行路由
    + express 这个对象身上, 有一个成员叫做 Router, 是一个函数
      => 当这个函数执行的时候会返回一个路由表(一个空的表格)
      => 我们就可以在这个表格上进行各种的路由配置
    + 得到空的表格以后, 我们向表格上添加内容
      => get(), post(), delete(), ...
      => 语法: xxx(路径标识符, 回调函数)
    + 告诉 app 服务, 你要使用这个表格
      => 方法 app.use(要使用的内容)
    + 就可以按照模块化开发的方式, 把路由表配置单独拿出去了
      => 把请求分类
      => 按照业务逻辑分类
        -> 用户相关
        -> 商品相关
        -> ...

  挂载路由表出现的问题
    => app.use 是有执行顺序的
    => 当你挂载了多张表以后, 就会出现后面的路由去前面的表路面空跑
    => 当你挂载多个路由表以后, 最好使用 app.use 进行分类
      -> 不属于你的路由不要进来
    => 我们可以约定好
      -> 用户相关的路由, 标识符以 /users 开头
      -> 商品相关的路由, 标识符以 /goods 开头
    => app.use()
      -> 第一个参数选填, 默认是 '*', 我们可以写一个字符串
        + 表示以这个字符串开头的标识符, 使用后面挂载的内容
      -> 第二个参数, 就是挂载的内容

*/
const express = require('express')
// 把我准备好的路由表导入进来
const userRouter = require('./route/users')
const goodsRouter = require('./route/goods')

const app = express()

// 告诉 app 使用这个路由表
// 只有以 /users 开头的请求, 会使用这个表
app.use('/users', userRouter)
// 告诉 app 这个表也要使用
app.use('/goods', goodsRouter)



app.listen(8080, () => console.log('running at port 8080!'))





// // 拿到一张空的表格
// const router = express.Router()

// // 像表格上添加一些内容
// router.get('/a', (req, res) => {
//   res.send('我是 get 请求的 /a 路径标识符')
// })

// // 告诉 app 你要使用哪一个路由表
// app.use(router)
