/*
  接收参数的处理
    + express 对于地址后面携带的参数做了单独处理
    + get 形式的参数
    + 在 req 里面添加了一个叫做 query 的成员
      => 里面就是解析好的请求参数
    + express 并没有处理 body
      => 虽然没有处理, 但是留下了接口


  插件: 叫做 body-parser
    -> 专门解析请求体的插件, 但是不能解析文件
    -> express 内置了这个插件, 不需要你单独下载

  使用
    1. 使用 express 内置
      + 挂载在 服务 上, 在进入路由之前, 把请求题解析好
      + 挂载 express.urlencoded()
      + 挂载以后, 会在 req 里面添加一个新的成员叫做 body
      + 里面就是所有请求的请求体信息
    2. 使用 body-parser 插件
      + 下载 body-parser
      + 导入 body-parser()
      + 挂载 app.use()
      + 挂载需要传递参数
        => extended: false
*/

const express = require('express')
const testRouter = require('./route/test')

// 导入 body-parser
const bodyParser = require('body-parser')

const app = express()

// 直接挂载一个解析请求体的方式
// app.use(express.urlencoded())

// 解析请求题, body-parser
app.use(bodyParser.urlencoded({ extended: false }))



app.use(testRouter)
app.listen(8080, () => console.log('running at port 8080 ! ^_^ '))
