// 准备一个测试的路由表
const router = require('express').Router()


router
  .get('/a', (req, res) => {
    // 准备接收参数
    const { url, query } = req
    console.log(url)
    console.log(query)

    res.send({
      message: '接收参数成功, 带回去给你看看',
      params: query
    })
  })
  .post('/a', (req, res) => {
    console.log(req.body)

    res.send({
      message: '接收 post 请求参数成功, 带回去你看看',
      body: req.body
    })
  })


module.exports = router
