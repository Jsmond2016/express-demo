// 任务: 创建出一个表就可以了
const express = require('express')

// 建立表
const router = express.Router()

// 向表里面添加内容
router.get('/getInfo', (req, res) => {
  res.send('我是 get 请求的 /getInfo 路径标识符')
})

router.post('/login', (req, res) => {
  res.send('我是 post 请求的 /login 路径标识符')
})

router.post('/reg', (req, res) => {
  res.send('我是 post 请求的 /reg 路径标识符')
})

// 导出这个表格
module.exports = router
