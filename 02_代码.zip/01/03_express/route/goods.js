// 任务: 配置一个商品相关的路由表
const router = require('express').Router()

// 进行路由表的配置
router
  .get('/goodsList', (req, res) => res.send('获取商品信息'))
  .post('/addGoods', (req, res) => res.send('添加商品'))


module.exports = router
