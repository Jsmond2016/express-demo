/*
  了解 express 框架
    + 后端框架之一
    + 框架 库 和 插件
      => 插件: 为了实现某一类功能而封装的代码
      => 库: 把所有的基础操作全部封装, 需要任何东西需要自己组装
      => 框架: 一套完整的自己的生态体系, 能帮你把大部分事情全部做完了
    + node 框架
      => 自己把所有的后端需要做的事情给你准备好
      => 把大部分的行为都封装成了方法(服务)
      => 预留了一个接口位置, 你可以把很多的插件直接注册进去

  使用
    1. 下载, npm i express
    2. 导入使用, const express = require('express')
    3. 创建服务,
      => express 导入进来以后就是一个函数, 执行就会返回一个服务
      => express()
      => 返回值就是一个服务
    4. 监听端口
      => listen(8080, () => {})
      => 依靠 express 创建的服务去监听端口

  express 返回响应
    + express 框架把所有的请求分类
      => 按照请求方式分类
      => get, post, delete, patch, put, ...
      => 分别使用 服务 去调用
    + 这些方法参数是一致的
      => xxx('路径', 请起处理函数)
    + 每一个请求处理函数里面 接收一个 req, res
      => req 表示本次请求的信息
      => res 表示本次响应的信息
      => res 里面多了一个方法叫做 send()
        -> 里面还是保留了 end 方法
        -> end 方法只能返回字符串类型
        -> send 方法当你返回一个其他数据类型的时候, 会给你自动转换成 json 格式返回
*/

// 2. 导入框架使用
const express = require('express')

// 3. 创建服务
const app = express()

// 处理各种情况
// 只有当你使用 get 方式发送请求, 并且发送请求时 /a 标识符的时候
// 才会触发这个函数
app.get('/a', (req, res) => {
  // console.log('我被触发了')

  // res.end({ name: 'Jakc', age: 18 })
  res.send({ name: 'Jakc', age: 18 })
})


// 4. 监听端口
app.listen(8080, () => console.log(' running at port 8080 ! ^_^ '))
