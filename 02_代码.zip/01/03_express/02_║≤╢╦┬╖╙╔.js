/*
  后端路由
    + 路由: 根据前端的不同请求给出不同个响应
    + 我们在处理业务逻辑的时候, 我们就可以把所有的请求分类方好
    + express 最初实现路由就是 app.get() app.post() ...

  express 的路由表
    + express 框架单独给我们出现的 API
    + 不进行路由的处理, 只是但如配置一张表
    + 把配置好的表, 交给服务, 让服务按照这个表的配置进行路由
*/

const express = require('express')

const app = express()


// 对每一个请求的分别处理就叫做 后端路由
app.get('/a', (req, res) => {
  res.send({ name: 'Jack', age: 18 })
})

app.post('/a', (req, res) => {
  res.send('我是接收了 post 请求的 /a 路径标识符')
})

app.delete('/a', (req, res) => {
  res.send('我是接受了 delete 请起的 /a 路径标识符')
})


app.listen(8080, () => console.log('running at port 8080!'))
