/*
  静态资源的配置
    + 前端的静态资源
      => 前端使用 js css images videos ... 第三方
      => 静态资源最好时统一以 /public 开头
    + express 给我们提供了一个静态资源的方法
      => 要求你都以一个统一的 /public 开头
      => 剩下的就以 public 以后的目录书写
    + express.static(静态资源存储路径)
      => 在所有路由表挂载的最前面挂载以下静态资源的处理
    + 配置静态资源的时候, 最好时配置两个
      -> 自己写的静态资源
      -> 第三方的静态资源
*/
const express = require('express')
const viewsRouter = require('./route/views')

const app = express()

// 挂载静态资源
// 所有的 /public 开头的都会去到 public 文件夹下寻找内容
// 按照你请求路径后面的内容去寻找
app.use('/public', express.static('./public'))
app.use('/node_modules', express.static('../node_modules'))

app.use('/views', viewsRouter)



app.listen(8080, () => console.log('running at port 8080!!!'))
