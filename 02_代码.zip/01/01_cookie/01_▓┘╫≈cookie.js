/*
  node 操作 cookie
    + 获取 cookie
    + 设置 cookie

  获取 cookie
    + cookie 是怎么来到后端的 ? 自动携带在请求头里面过来的
    + req 就是本次请求的所有内容
      => req 里面有一个信息叫做 headers
      => 拿到的就是本次请求的请求头
    + req.headers.cookie

  设置 cookie
    + 后端设置 cookie 是在响应头里面设置
    + 设置 cookie 就是在写一段响应头
    + res.writeHead(200, { 配置信息 })
      => 设置一条 cookie: { 'set-cookie': 'cookie内容' }
      => 设置带有过期时间: { 'set-cookie': 'cookie内容;expires=时间' }
        -> 后端拿到的就是服务器时间
        -> 2020-09-01T00:20:10.160Z   服务端格式
        -> cookie 不认识服务端格式的, 必须要用 客户端格式
*/

const http = require('http')
const fs = require('fs')
const url = require('url')

http.createServer((req, res) => {

  if (req.url === '/index.html') {

    // 打印请求头
    // console.log(req.headers)

    // node 获取 cookie
    const cookie = req.headers.cookie || ''
    console.log(cookie) // a=100; b=200; c=300
    // const obj = {}
    // cookie.split('; ').forEach(item => {
    //   const t = item.split('=')
    //   obj[t[0]] = t[1]
    // })
    // console.log(obj)

    // const result = url.parse('?' + cookie.replace(/; /g, '&'), true)
    // console.log(result)


    fs.readFile('./index.html', (err, data) => {
      if (err) return console.log(err)

      console.log(new Date().toGMTString())

      // 写入响应头
      res.writeHead(200, {
        'set-cookie': 'd=400;expires=' + new Date(2020, 8, 1, 9, 00, 00).toGMTString()
      })


      // 给出响应
      res.end(data)
    })


  }


}).listen(8080, () => { console.log('running at port 8080! ^_^ ') })
