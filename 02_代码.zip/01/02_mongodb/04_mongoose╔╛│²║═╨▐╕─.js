/*
  mongoose 修改的删除的方法

  1. 删除多个
    => deleteMany({ 条件 }).then()
    => 删除多个, 只要满足条件的都会删除
    => 条件也可以写多个
  2. 删除一个
    => deleteOne({ 条件 }).then()
    => 删除一个, 找到数据库中满足条件的第一个删除
    => 条件可以写多个
  3. 修改多个
    => updateMany({ 条件 }, { 要修改成什么 }).then()
    => 根据条件修改多个, 只要满足条件的都修改
    => 条件可以写多个
  4. 修改一个
    => updateOne({ 条件 }, { 要修改成什么 }).then()
    => 根据条件, 把满足条件的第一个修改掉
    => 条件可以写多个
*/

// 0. 导入 mongoose
const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost:27017/gp19', { useNewUrlParser: true, useUnifiedTopology: true }, (err, info) => {
  if (err) return console.log(err)
  console.log('连接成功')
})
const users = new mongoose.Schema({
  username: String,
  age: {
    type: Number,
    min: 18,
    max: 60
  },
  gender: {
    type: String,
    // 这个位置的值必须是这个数组里面的内容
    enum: ['男', '女', '保密']
  },
  hobby: Array,
  desc: {
    type: String,
    minlength: 5,
    maxlength: 10,
    default: '我是一个管理员'
  },
  createTime: {
    type: Date,
    default: Date.now()
  }
})

// 建立模型的时候, 根据结构建立模型, 如果有这个表, 那么就不再建立表
const UserModel = mongoose.model('user', users)


// 1. 删除多个
// UserModel.deleteMany({
//   age: 22
// }).then(res => console.log(res))


// 2. 删除一个
// UserModel.deleteOne({
//   age: 24
// }).then(res => console.log(res))


// 3. 修改多个
// UserModel.updateMany({
//   age: { $gte: 20, $lt: 60 }
// }, {
//   // 修改的时候要遵循你创建的时候的规则
//   gender: '保密'
// }).then(res => console.log(res))


// 4. 修改一个
// UserModel.updateOne({ gender: '保密' }, { age: 33 }).then(res => console.log(res))
