/*
  1. 解决警告问题
    => 解析 url 地址的问题
    => 需要在第二个参数进行一些配置, 以对象的形式
    => useNewUrlParser: true
    => useUnifiedTopology: true

  2. 集合可以填写的类型
    => key : 数据类型(String, Number, Boolean, Array)
    => key : { type: String, minlength: 5, maxlength: 10, ... }

  3. 查询和筛选查询
    3-1. 查询
      => 查询所有内容
      => 直接利用模型使用 find()
    3-2. 筛选查询
      => 需要在 find 以后使用
        -> or([{}, {}, {}])
        -> and([{}, {}])
        -> where({})
      => 还有一种筛选查询的方式
        -> 直接在 find({ 筛选条件 })
      => 还有一种筛选方式
        -> 纯链式变成
        -> find().where('age').gt(20).lt(30)
        -> skip() 从哪一个索引位置获取
        -> limit() 获取多少个
    3-3. 条件书写
      => age: 20
      => age: { $gt: 20 }
      => age: { $lt: 20 }
      => age: { $gt: 20, $lt: 30 }
    3-4. 其他查询方法
      => 直接利用模型调用
      => findbyId()
      => findByIdAndDelete()
      => findByIdAndRemove()
      => findByIdAndUpdate()
      => findOne()
      => findOneAndRemove()
      => findOneAndDelete()
      => findOneAndUpdate()

*/

// 0. 导入 mongoose
const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost:27017/gp19', { useNewUrlParser: true, useUnifiedTopology: true }, (err, info) => {
  if (err) return console.log(err)
  console.log('连接成功')
})
const users = new mongoose.Schema({
  username: String,
  age: {
    type: Number,
    min: 18,
    max: 60
  },
  gender: {
    type: String,
    // 这个位置的值必须是这个数组里面的内容
    enum: ['男', '女', '保密']
  },
  hobby: Array,
  desc: {
    type: String,
    minlength: 5,
    maxlength: 10,
    default: '我是一个管理员'
  },
  createTime: {
    type: Date,
    default: Date.now()
  }
})
const UserModel = mongoose.model('user', users)


// 3-1. 基础查询, 查询表中的所有数据
// UserModel
//   .find({ username: '你好', age: { $gt: 20, $lt: 30 } })
//   // .or([{ username: 'Jack' }, { age: 18 }])
//   // .and([{ username: 'Jack' }, { age: 18 }])
//   // .where({ age: { $gte: 20, $lt: 30 } })
//   .then(res => {
//     console.log(res)
//   })

// 3-1. 基础查询, 链式编程
// UserModel
//   .find()
//   .where('age')
//   .gte(18)
//   .lte(20)
//   .then(res => {
//     console.log(res)
//   })

// 3-1. 基础查询, 查询多少个
// UserModel
//   .find()
//   .skip(12)
//   .limit(3)
//   .then(res => {
//     console.log(res)
//     console.log(res.length)
//   })

// 3-4. 其他查询方法
// UserModel.findById('5f4da485530415140c1aff3a').then(res => console.log(res))

// UserModel.findByIdAndDelete('5f4da485530415140c1aff3a').then(res => console.log(res))

// UserModel.findByIdAndUpdate('5f4da44e233ea447b4ef9bfb', {
//   username: 'hello world'
// }).then(res => console.log(res))

// UserModel.findOne({ age: 22 }).then(res => console.log(res))
