/*
  了解 mongodb
    + 和 mysql 的区别
      => mysql 都是关系型数据库
        -> 存储, 多表存储, 每一个表里面可以写一个信息, 和其他表关联
        -> 多表联合查询
        -> 多表之间可以存在联系, 可以使用 sql 语句让多张表联合在一起
      => mongodb 是非关系型数据库
        -> 存储, 以集合(库 database)的形式存储
        -> 集合里面都是以 json 文件的格式在存储
        -> 多个表之间没有联系, 不能通过语句来产生联系(因为根本没有固定语句)

  安装 mongodb 数据库
    1. 官网下载
    2. 双击安装
    3. 使用, 找到你的 mongodb 安装目录, 进去以后切换到 bin 目录
      -> 在 bin 目录下使用 mongod 指令来运行
      -> mongodb 安装完毕以后, 只是一个服务, 没有磁盘空间来写内容
      -> 我们要自己创建一个文件夹
      -> 使用指令 $ mongod --dbpath e:data
    4. 为了使用方便
      -> 把 mongodb 配置到环境变量里面
      -> 找到 mongodb 的 bin 目录
      -> 把 bin 目录的绝对路径写入到 环境变量
        + win7: C:\Program Files\MongoDB\Server\4.0\bin;asdasdasd;asdasdasdasdasd;asdasdsadsadasd;asdasdasdsadasd;
        + win10: 新建一条, 直接写上
      -> 环境变量配置好以后, 你在电脑的任何一个位置打开 cmd 都可以启动 mongod
    5. 为了更方便
      -> 新建文本文档
      -> 写入 mongod --dbpath e:data
      -> 把后缀改成 .bat
    注意: 每次你要使用 mongodb 数据库的时候, 必须要使用 mongod 执行启动服务


  安装 robo 3t 的工具
    + 是一个 mongodb 的可视化工具
    + 简洁版的可视化工具
    1. 官网下载
      => 建议你们下一个双包
    2. 双击安装
      => 一路下一步
      => 找到一个你喜欢的位置
    3. 使用
      => 在 mongodb 服务启动的情况下
      => 直接双击打开就可以操作你本地的 mongodb 数据库
*/
