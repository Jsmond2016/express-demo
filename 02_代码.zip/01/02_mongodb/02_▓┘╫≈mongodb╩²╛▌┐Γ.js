/*
  操作 mongodb 数据库
    + 使用一个第三方包叫做 mongoose
      => 专门用来操作 mongodb 数据库
      => 直接下载导入使用就可以了

  mongoose 操作 mongodb 数据库
    1. 先把流程走下来
      1-1. 保证你的 mongodb 服务是开启的
      1-2. 使用 mongoose 里面的 connect 方法连接到 数据库
        => 语法: mongoose.connect(url, 回调函数)
        => url: 就是你本地 mongodb 的服务地址
        => mongodb://localhost:27017/test
        => 最后的 /test 就是你要操作的 database
          -> 如果你没有这个库, 他会给你建立一个
          -> 如果你有这个库, 就直接进去了
      1-3. 创建一个结构
        => 使用 mongoose.Schema({ 集合的配置信息 })
        => 是一个构造函数, 我们需要 new 一个实例
        => 配置哪些字段, 使用什么数据格式
        => 得到的是一个 结构实例
      1-4. 创建一个数据库操作模型
        => 其实就是一个对象, 用来操作数据库中指定哪一张表的
        => mongoose.model(表明, 所用的表格式)
          -> 表名: 必须是一个复数形式
          -> 所用的表格式: 必须是 Schema 的实例对象
        => 返回一个和表连接好的操作模型对象
        => 基本上操作数据库就是用或者返回的 模型 来操作
      1-5. 存储一条数据进去
        => 创建一个数据信息存储进去
        => new 操作模型().save()
*/

// 0. 导入 mongoose
const mongoose = require('mongoose')

// 1-2. 连接到数据库
mongoose.connect('mongodb://localhost:27017/gp19', (err, info) => {
  if (err) return console.log(err)
  console.log('连接成功')
})

// 1-3. 创建一个结构
const users = new mongoose.Schema({
  username: String,
  age: Number,
  gender: String
})

// 1-4. 获取表的操作模型(进入那一张表)
const UserModel = mongoose.model('user', users)

// 1-5. 存储一条信息
new UserModel({
    username: '李思',
    age: 22,
    gender: '女'
  })
  .save()
  .then(res => {
    console.log(res)
    console.log('存储成功')
  })
  .catch(err => {
    console.log(err)
    console.log('存储失败')
  })
