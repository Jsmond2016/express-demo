# 案例

  1. 登录功能
    - 用户名和密码的验证
    - 验证码发送到邮箱(为了方便, 开发完毕最后实现)
  2. 首页
    - 渲染一下昵称
  3. 个人中心页面
    - 登录验证, 不登陆状态下直接跳转回登陆页面
    - 用户信息的渲染
    - 用户信息修改
  4. 修改密码页面
    - 根据原始密码修改新密码



## 实现页面

  - express 实现服务
  - express-art-template 实现 res.render()
      - 为了渲染页面, 自动读取, 自动组装, 自动返回
      - 依赖一个 art-template
  ```javascript
    // app.js
    const express = require('express')
    const app = express()

    // 1. 引擎注册 express-art-template
    app.engine('html', require('express-art-template'))
    // 如果你需要修改文件夹
    app.set('views', __dirname + '/pages')

    app.listen()
  ```
  ```javascript
    // viewRouter.js
    router.get('页面', (req, res) => {})
    router.get('页面', (req, res) => {})
    router.get('页面', (req, res) => {})
    router.get('页面', (req, res) => {})
    // userRouter.js
    router.get('/getInfo', (req, res) => {})
    router.post('/update', (req, res) => {})
    router.post('/updatePwd', (req, res) => {})
    router.post('/login', (req, res) => {})
  ```



## 处理静态资源

  - 使用 express.static()
  ```javascript
    app.use('/public', express.static('路径'))
    app.use('/node_modules', express.static('路径'))
  ```



## 实现登录

  1. 接收前端发来的用户名和密码
    + 进行数据库比对的验证
    + 需要用到 mongoose 数据库
    + 数据库操作单独封装
  ```javascript
    const mongoose = express('mongoose')
    // 连接数据库
    mongoose.connect('路径')

    // 创建结构
    const user = new mongoose.Schema({
      email: 字符串类型, 必填
      password: 字符串类型, 必填, 6 ~ 12 位
      age: 数值类型, 默认值, 0
      gender: 字符串类型, 枚举类型, 默认值, 保密
      phone: 字符串类型, 限定长度, 11
      desc: 字符串类型, 限定长度, 200
      avatar: 字符串类型, 默认值, 没有图片的时候使用默认路径
      hobby: 数组类型
    })

    // 创建模型
    mongoose.model('users', user)

    // 数据库操作

  ```

  2. 配置路由
    + 添加一个接收 login 请求的路由
    + 因为 login 需要 post 请求
    + 接收请求体
    + 配置接收
    ```javascript
    // body-parser
    // express 自己带的
    app.use(express.urlencoded())
    ```

  3. 验证登录
    - 一定要自己验证一遍数据
      + 保证有
      + 保证格式是对的
    - 再去数据库查询
    - 为了保持登录状态, 需要使用到 cookie + session 来保持登录状态
    - 需要 express-session, connect-mongo
    ```javascript
      const session = require('session')
      const MongoStore = require('connect-mongo')(session)

      // 挂载到 app 商
      app.use(session({
        screct: 'guoxiang',
        name: 'sessid',
        resave: true,
        saveUnxxxx: true,
        cookie: { maxAge: 1000 * 60 },
        store: new MongoStore({
          url: '地址'
        })
      }))
    ```


## 首页的业务逻辑

  - 在页面的路由中进行判断
    + 如果登录了, 需要渲染一种结果
    + 如果没有登录, 需要渲染一种结果
  ```javascript
  if (req.session.userInfo) {}
  ```



## 个人中心的业务逻辑

  - 登录验证
      + 如果没有登录, 直接回到登陆页面
      + 直接在路由里面就可以验证
  ```javascript
    if (!req.session.userInfo) return res.redirect('登录页面')

    // 展示个人中心页面, 数据要渲染好
  ```
  - 根据当前用户的信息把表单渲染好
  - 接收前端传递来的数据
  - 因为有文件, 需要 multer
  ```javascript
  const multer = require('multer')

  // 准备一个仓库信息
  const storage = multer.diskStorage({
    destination () {},
    filename () {}
  })

  const avatar = multer({ storage: storage })

  // 路由中使用
  ```
  - 进行数据验证
  - 存储到数据库里面
  ```javascript
  // session 里面有用户 id
  findByIdAndUpdate()
  ```



## 修改密码页面的业务逻辑

  - 登录验证, 如果没有登陆过, 那么直接跳转回登陆页面
  - 修改密码的路由里面验证
      + 数据格式
      + 两次密码一致
  - 拿到 session 里面存储的 id
      + 根据 id 查询数据, 查询到以后, 对比旧密码是不是正确
  - 保证旧密码是对的
      + 开始修改密码
      + 修改密码完成要强制让用户从新登录
      + 注销登录状态(删除 cookie 可以做, 但是不是很好)(删除 session 空间内部的 userInfo)


## 登录时验证码的业务逻辑

  - 用户点击发送验证码的时候
      + 前端发送一个请求, 告诉后端要发送验证码
      + 后端把验证码发送到邮箱, 发送成功的时候, 返回一个结果
      + 前端把 "验证码以发送到邮箱" 信息提示给用户
    ```javascript
      const nodeMailer = require('nodemailer')

      // 创建一个发送器
      const transport = nodeMailer.createTransport({
        xxx: xxx
      })

      // 使用发送器发送邮件
      transport.sendMail({
        from: '',
        to: '',
        subject: '',
        html: ''
      })

    ```
  - 用户点击登录的时候
      + 验证验证码是否携带
      + 后端验证验证码是不是刚才我给你的
      + 后端先验证 验证码, 后验证 用户名和密码
  - 登录成功以后, 验证码失效
      + 登录成功以后, 把req.session.code = null
