// 导入第三方
const nodeMailer = require('nodemailer')

// 创建发送器
const transport = nodeMailer.createTransport({
  "host": "smtp.qq.com",
  "port": 465,
  "secure": true,
  auth: {
    // user: '493405058@qq.com',
    user: '305859189@qq.com',
    pass: 'pzxzvskshvpabjgd'
  }
})

// 导出发送器
module.exports = transport
