const form = document.querySelector('form')
const nameInp = document.querySelector('input[name=username]')
const pwdInp = document.querySelector('input[name=password]')
const codeInp = document.querySelector('[name=code]')
const cInp = document.querySelector('input[name=c]')

form.addEventListener('submit', function (e) {
  e.preventDefault()

  const username = nameInp.value
  const password = pwdInp.value
  const code = cInp.value

  // 表单验证
  if (!username || !password || !code) return window.alert('请完整填写表单')

  // 发送请求
  const xhr = new XMLHttpRequest()

  xhr.open('POST', '/users/login')

  xhr.onload = function () {
    const { message, code } = JSON.parse(xhr.responseText)

    if (code === 0) return window.alert(message)

    window.location.href = './index.html'
  }

  xhr.setRequestHeader('content-type', 'application/x-www-form-urlencoded')

  xhr.send(`email=${ username }&password=${ password }&code=${ code }`)
})

codeInp.addEventListener('click', function () {
  // 发送请求到后端, 告诉你发送一个验证码给用户
  // 携带一个邮箱
  // 1. 确认邮箱已经填写
  const email = nameInp.value

  if (!email) return window.alert('请填写邮箱')

  // 2. 有邮箱信息, 直接发送请求
  const xhr = new XMLHttpRequest()
  xhr.open('GET', '/users/code?email=' + email)
  xhr.send()
  xhr.onload = function () {
    const { message } = JSON.parse(xhr.responseText)

    window.alert(message)
  }
})
