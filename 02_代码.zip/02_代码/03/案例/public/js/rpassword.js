const form = document.querySelector('form')
const oldInp = document.querySelector('input[name=oldPwd]')
const newInp = document.querySelector('input[name=newPwd]')
const rInp = document.querySelector('input[name=rPwd]')

form.addEventListener('submit', e => {
  e.preventDefault()

  const oldPwd = oldInp.value
  const newPwd = newInp.value
  const rPwd = rInp.value

  // 表单验证
  if (!oldPwd || !newPwd || !rPwd) return window.alert('请完整填写表单')

  // 重复密码的验证
  if (newPwd !== rPwd) return window.alert('两次填写密码不一样')

  // 发送请求
  const xhr = new XMLHttpRequest()
  xhr.open('POST', '/users/updatePwd')
  xhr.setRequestHeader('content-type', 'application/x-www-form-urlencoded')
  xhr.send(`oldPwd=${ oldPwd }&newPwd=${ newPwd }&rPwd=${ rPwd }`)
  xhr.onload = function () {
    const { code, message } = JSON.parse(xhr.responseText)

    if (code === 0) return window.alert(message)

    // 跳转回登录页
    window.location.reload()
  }

})
