// 上传图片的操作应该在本地先进行预览
// 确认好了以后, 最后上传的时候一起传递过去
/*
  H5 的标准中有一个 FileReader
    + 做本地图片预览
*/

// 0. 全局定义一个变量, 接收图片信息
let avatarInfo = null

// 1. 拿到 file 标签
const file = document.querySelector('input[type=file]')
const img = document.querySelector('.avatar > img')
// 2. 给他绑定一个 change 事件
file.addEventListener('change', function (e) {
  // 3. 拿到图片信息
  const avatar = e.target.files[0]

  // 3-2. 进行一个严谨性的判断. 万一你点击的是取消, 那么我就不需要后面
  if (!avatar) return

  // 4. 使用 FileReader 解析这个图片
  const fd = new FileReader()
  // 5. 使用 fn 身上的方法来解析(解析成 base64 编码)
  fd.readAsDataURL(avatar)
  // 6. 解析完毕触发的事件
  fd.onload = function () {
    // 你选择的有可能不是一个 图片
    // 7-1. 做一个严谨性的判断
    if (!fd.result.startsWith('data:image')) return

    // 7-2. 赋值给 img 标签
    img.src = fd.result
    // 8. 因为你最终上传的时候需要上传文件信息
    avatarInfo = avatar
  }
})


// 给确认修改添加点击事件
const form = document.querySelector('form')
const phoneInp = document.querySelector('input[name=phone]')
const ageInp = document.querySelector('input[name=age]')
const descInp = document.querySelector('textarea[name=desc]')
const hobbyInps = document.querySelectorAll('input[name=hobby]')
const genderInps = document.querySelectorAll('input[name=gender]')
form.addEventListener('submit', function (e) {
  e.preventDefault()
  // 使用 formData 的形式上传
  // 可以捕获 form 里面所有有 name 属性的 标签的值
  // 不需要 FormData 帮我直接抓取内容, 我们手动添加内容
  const fd = new FormData()

  // 手动添加内容
  // 头像信息
  if (avatarInfo) fd.append('avatar', avatarInfo)
  // 手机号信息
  fd.append('phone', phoneInp.value)
  fd.append('age', ageInp.value)
  fd.append('desc', descInp.value)

  const hobby = []
  hobbyInps.forEach(item => {
    if (item.checked === true) hobby.push(item.value)
  })
  fd.append('hobby', hobby)

  let gender = ''
  genderInps.forEach(item => {
    if (item.checked) gender = item.value
  })
  fd.append('gender', gender)

  // 上传到服务端
  const xhr = new XMLHttpRequest()
  xhr.open('POST', '/users/update')
  xhr.send(fd)
  xhr.onload = function () {
    const { code, message } = JSON.parse(xhr.responseText)

    if (code === 0) return window.alert(message)

    window.location.href = '/views/login.html'
  }
})
