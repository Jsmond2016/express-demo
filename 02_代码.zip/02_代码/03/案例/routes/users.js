const router = require('express').Router()

// 导入正则验证工具库
const { testEmail, testpwd, testPhone, testGender } = require('../utils/reg')

// 导入数据库模型
const { UserModel } = require('../db/db')

// 导入文件接收器
const { avatar } = require('../utils/multer')

// 导入邮件发送器
const transport = require('../utils/mailer')

// 配置路由表

// 1. 登录
router.post('/login', async (req, res) => {
  // 接收请求体
  const { email, password, code } = req.body

  // 1-1. 参数验证
  if (!email || !password || !code) return res.send({ message: '请完整填写表单!', code: 0 })

  // 1-2. 表单格式验证
  if (!testEmail(email) || !testpwd(password)) return res.send({ message: '按照规则填写表单!', code: 0 })

  // 1-2. 验证验证码
  if (req.session.code !== code) return res.send({ message: '验证码不正确, 请重新获取', code: 0 })

  // 1-3. 去数据库操作
  const result = await UserModel.findOne({ email, password })

  // 1-4. 根据结果给出信息
  if (!result) return res.send({ message: "用户名密码错误!", code: 0 })

  // 表示登录成功
  // 存储一个标识符, 直接把用户信息存储进去
  req.session.userInfo = result
  // 让验证码失效
  req.session.code = null

  // 给出正确的响应
  res.send({ message: '登录成功', code: 1 })
})

// 2. 修改个人信息
router.post('/update', avatar.single('avatar'), async (req, res) => {
  const { file, body: { phone, age, desc, hobby, gender } } = req
  // 参数验证
  if (!testPhone(phone) || desc.length > 200 || !testGender(gender)) return res.send({ message: '修改失败, 参数有问题!', code: 0 })

  const filename = file && file.filename

  console.log(desc)

  // 将来要修改的信息
  const userInfo = {
    avatar: filename ? '/public/avatar/' + filename : '',
    phone,
    age,
    desc,
    gender,
    hobby: hobby.split(',')
  }

  // 使用方法去修改
  UserModel
    .updateOne({ _id: req.session.userInfo._id }, userInfo)
    .then(() => {
      res.send({ message: '修改成功', code: 1 })
    })
    .catch(err => console.log(err))
})

// 3. 修改密码
router.post('/updatePwd', async (req, res) => {
  // 直接从 req.body 里面拿到参数
  const { oldPwd, newPwd, rPwd } = req.body

  // 验证数据格式是正确的
  if (!testpwd(oldPwd) || !testpwd(newPwd) || !testpwd(rPwd)) return res.send({ message: '请按照规则填写表单!', code: 0 })

  // 验证重复密码
  if (newPwd !== rPwd) return res.send({ message: '两次密码不一致', code: 0 })

  // 存储到数据库里面
  // 拿到 session 里面存储的 _id
  const { _id } = req.session.userInfo

  // 根据 _id 去数据库拿到数据
  const result = await UserModel.findById(_id)

  // 对比旧密码是不是正确
  if (result.password !== oldPwd) return res.send({ message: '密码不正确', code: 0 })

  // 修改密码
  await UserModel.findByIdAndUpdate(_id, { password: newPwd })

  // 把 session 空间的 userInfo 删除掉
  delete req.session.userInfo

  // 返回给前端结果
  res.send({ message: '修改密码成功', code: 1 })
})

// 4. 发送验证码
router.get('/code', (req, res) => {
  const { email } = req.query

  if (!email) return res.send({ message: '请填写邮箱', code: 0 })

  // 生成一个随机验证码
  //    1. 再函数内部定义, 其他函数不能使用
  //    2. 定义再全局, 那么当两个用户同时发送验证码的时候, 只有第二个用户可以成功验证
  //    3. 放在 session 空间里面, 因为一个人一个空间, 互不干涉
  const code = Math.random().toString().slice(-4)
  req.session.code = code

  setTimeout(() => {
    req.session.code = null
  }, 1000 * 60 * 3)

  transport.sendMail({
    from: '493405058@qq.com',
    to: email,
    subject: '验证码',
    html: `
      您好! 本次的验证码是
      <h1 style="color: red;"> ${ code } </h1>
      本次验证码三分钟内有效, 请及时登录

      </br>
      ----------------
      啥都有科技股份有限公司
    `
  }, (err, info) => {
    if (err) return console.log(err)

    res.send({ message: '验证码以发送到邮箱, 请查收!', code: 1 })
  })
})

// 导出路由表
module.exports = router
