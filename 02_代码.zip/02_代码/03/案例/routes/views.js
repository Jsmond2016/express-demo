// 生成路由表
const router = require('express').Router()

// 配置路由表
router.get('/index.html', (req, res) => {

  // 进行判断
  if (!req.session.userInfo) return res.render('./index.html', { txt: '去登陆', title: '请登录', url: '/views/login.html' })

  // 直接返回页面
  res.render('./index.html', { txt: '个人中心', title: req.session.userInfo.email, url: '/views/self.html' })
})

router.get('/login.html', (req, res) => {

  // 直接返回页面
  res.render('./login.html')
})

router.get('/self.html', (req, res) => {
  const { userInfo } = req.session

  // 进行登录验证
  if (!userInfo) return res.redirect('/views/login.html')

  // 直接返回页面
  // 把要渲染的数据放进去, 渲染页面
  // console.log(userInfo)
  // 因为爱好是一个数组, 我们准备好数据直接渲染
  const hobby = [ { value: '吃饭', isChecked: false }, { value: '睡觉', isChecked: false }, { value: '玩游戏', isChecked: false } ]
  // 想办法根据 userInfo 的 hobby 信息, 把 hobby 数组改变一下 isChecked 属性
  userInfo.hobby.forEach(item => {
    hobby.forEach(item2 => {
      if (item2.value === item) item2.isChecked = true
    })
  })

  res.render('./self.html', { userInfo, hobby })
})

router.get('/rpassword.html', (req, res) => {
  // 只要 session 空间里面没有 userInfo 信息, 就是没有登录
  if (!req.session.userInfo) return res.redirect('/views/login.html')


  // 直接返回页面
  res.render('./rpassword.html')
})

// 导出路由表
module.exports = router
