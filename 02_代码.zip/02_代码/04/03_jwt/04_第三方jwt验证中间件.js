/*
  express-jwt
    + 是一个 express 框架和 jwt 结合的第三方中间件
    + 作用: 验证 token

  使用
    1. 下载: npm i express-jwt
    2. 导入
    3. 注册为中间件
      => 语法: app.use( expressJWT({ 配置 }).unless({ 配置 }) )
    注意: 如果你要使用 express-jwt
      => 你必须有一个全局错误中间件

  正常的 token 返回给前端
    + 需要写成 Bearer token
*/

const express = require('express')
const jwt = require('jsonwebtoken')
const expressJWT = require('express-jwt')
const cors = require('cors')
const router = express.Router()
const app = express()

app.use(cors())

// app.use() 里面放的 expressJWT().unless()
// 注册 token 验证中间件
app.use(expressJWT({
  // 解析口令, 需要和加密的时候一致
  secret: 'guoxiang',
  // 加密方式: SHA256 加密方式在 express-jwt 里面叫做 HS256
  algorithms: ['HS256']
}).unless({
  // 不需要验证 token 的路径标识符
  path: ['/login', '/banner']
}))




router.get('/login', (req, res) => {
  // 默认登录成功

  const userInfo = {
    username: '郭翔',
    age: 18
  }

  // 生成一个 token 返回给前端
  const token = 'Bearer ' + jwt.sign(userInfo, 'guoxiang', { expiresIn: 60 })

  res.send({ message: '登录成功', code: 1, token })
})

// 第二次测试
router.get('/cartInfo', (req, res) => {
  res.send({ message: '获取购物车数据成功', code: 1 })
})

router.get('/pay', (req, res) => {
  res.send({ message: '支付成功', code: 1 })
})

router.get('/banner', (req, res) => {

  res.send({ message: '轮播图数据获取成功', code: 1, list: [ {}, {} ] })
})

app.use(router)


// 错误处理中间件
app.use((err, req, res, next) => {
  res.send({ err })
})

app.listen(8080, () => console.log('running at 8080'))
