const express = require('express')
const jwt = require('jsonwebtoken')
const cors = require('cors')
const router = express.Router()
const app = express()

app.use(cors())


// 准备一个 token 验证的中间件
app.use(function (req, res, next) {
  // req.url 表示当前地址
  const { url, headers: { authorization: token } } = req
  // const url = req.url
  // const { authorization: token } = req.headers
  // const token = req.headers.authorization

  // 不需要验证的 请求地址
  if (url === '/login' || url === '/banner') return next()

  // 来到这里表示需要 token 验证
  if (!token) return res.send({ message: '请携带 token 请求', code: 0 })

  jwt.verify(token, 'guoxiang', (err, data) => {
    if (err && err.message === 'invalid token') return res.send({ message: '无效 token', code: 0 })

    if (err && err.message === 'jwt expired') return res.send({ message: 'token 失效', code: 0 })

    next()
  })
})




router.get('/login', (req, res) => {
  // 默认登录成功

  const userInfo = {
    username: '郭翔',
    age: 18
  }

  // 生成一个 token 返回给前端
  const token = jwt.sign(userInfo, 'guoxiang', { expiresIn: 60 })

  res.send({ message: '登录成功', code: 1, token })
})

// 第二次测试
router.get('/cartInfo', (req, res) => {

  res.send({ message: '获取购物车数据成功', code: 1 })
})


router.get('/pay', (req, res) => {

  res.send({ message: '支付成功', code: 1 })
})


// 第一次测试
// router.get('/cartInfo', (req, res) => {
  // 你想要购物车数据
  // 那么你必须登录以后
  // 验证 token 是不是正确
  // req, 是本次请求的信息
  // req.headers 就是本次的请求头
  // const token = req.headers.authorization

  // // 1. 有没有
  // if (!token) return res.send({ message: '该请求需要 token', code: 0 })

  // // 2. 对不对
  // jwt.verify(token, 'guoxiang', (err, data) => {
  //   if (err && err.message === 'invalid token') return res.send({ message: '无效 token', code: 0 })

  //   if (err && err.message === 'jwt expired') return res.send({ message: 'token 失效', code: 0 })

  //   res.send({ message: '获取购物车数据成功', code: 1 })
  // })

// })

router.get('/banner', (req, res) => {
  // 你需要轮播图信息
  // 不需要登录验证

  res.send({ message: '轮播图数据获取成功', code: 1, list: [ {}, {} ] })
})

app.use(router)

app.listen(8080, () => console.log('running at 8080'))
