/*
  测试使用 jwt
    + jsonwebtoken
    + 专门生成 token 和解析 token 的一个第三方

  使用
    1. 下载: npm i jsonweb token
    2. 导入:
    3. 使用
      => 生成: jwt.sign(你要保存的信息, 口令, 参数)
        -> 保存的信息
        -> 口令: 加密口令, 加密的时候混入信息使用, 解密的时候还要这个口令
        -> 参数: 是一个对象, {}
          + expiresIn: 过期时间,单位为秒 ('1d')
      => 解码: jwt.verify(你要解析的 token, 口令, 回调函数)
        -> token: 必须是一个指定的 token
        -> 口令: 必须是加密时候的口令
        -> 回调函数: 接收结果
*/

// 准备一个信息
const userInfo = {
  _id: '2131245655',
  username: '郭翔',
  age: 18,
  gender: '男'
}

// 0. 导入
const jwt = require('jsonwebtoken')

// 1. 生成一个 token
// const res = jwt.sign(userInfo, 'guoxiang', { expiresIn: 20 })
// console.log(res)

// eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.
// eyJfaWQiOiIyMTMxMjQ1NjU1IiwidXNlcm5hbWUiOiLpg63nv5QiLCJhZ2UiOjE4LCJnZW5kZXIiOiLnlLciLCJpYXQiOjE1OTkxOTk2MDYsImV4cCI6MTU5OTE5OTYxNn0.
// Cg-PxkAzTnCUF9xja1O9gcOmRzaRsw4TlFM2nCZenAw
console.log('============================================')


// 2. 解码
// setTimeout(() => {
//   jwt.verify(res, 'guoxiang', (err, data) => {
//     console.log('第一次 1.5s')
//     if (err) return console.log(err)

//     console.log(data)

//     console.log('====================')
//   })

// }, 1500)

// setTimeout(() => {
//   jwt.verify(res + 'a', 'guoxiang', (err, data) => {
//     console.log('第二次 1.5s 错误 token')
//     if (err) return console.log(err)

//     console.log(data)

//     console.log('====================')
//   })

// }, 2000)

// setTimeout(() => {
//   jwt.verify(res, 'guoxiang', (err, data) => {
//     console.log('第三次 5s')
//     if (err) return console.log(err)

//     console.log(data)
//     console.log('=============================')
//   })
// }, 5000)


// eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiIyMTMxMjQ1NjU1IiwidXNlcm5hbWUiOiLpg63nv5QiLCJhZ2UiOjE4LCJnZW5kZXIiOiLnlLciLCJpYXQiOjE1OTkyMDAwMjksImV4cCI6MTU5OTIwMDA0OX0.LN9UU403wugNuCfUdsSn5t4yVgUW_OQBC42dnJ-YD4k
