const express = require('express')
const app = express()

// 导入路由表
const router = require('./routes/router')

// 挂载路由表
app.use(router)

app.listen(8080, () => console.log('running at 8080!'))
