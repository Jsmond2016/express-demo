// 模型

exports.addUser = function (userInfo) {
  // 执行存储进入数据库得操作
  // 以 promise 得形式封装
}
