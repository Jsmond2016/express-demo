// 存储中间件

exports.middleA = function middldA(req, res, next) {

}
