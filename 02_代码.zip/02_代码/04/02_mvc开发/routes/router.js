const router = require('express').Router()

// 导入控制器
const { handlerA } = require('../controllers/ctrl')
// 导入中间件
const { middleA } = require('../middleware/middle')


router.get('/a', middleA, handlerA)


module.exports = router
