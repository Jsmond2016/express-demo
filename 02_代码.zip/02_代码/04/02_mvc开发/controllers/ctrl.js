// 导入 model
const { addUser } = require('../model/model')

// 路由处理函数控制器
exports.handlerA = async function handlerA(req, res) {
  // 把用户信息存储到数据库
  const result = await addUser()


  res.send({ message: '添加用户成功', code: 1 })
}
