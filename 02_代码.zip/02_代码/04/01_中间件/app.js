/*
  中间件
    + 再两个事情中间, 给你 断开, 加入一个内容
    + 加入得这个内容, 可以做一些事情, 可以选择继续走下一条路 next
    + 根据加入位置得不同, 叫做不同得名字
      1. 全局中间件 req, res, next
        => 所有请求都要经历, 直接挂载再 app 上
        => app.use(函数)
      2. 路由级中间件 req, res, next
        => 再进入路由表, 到匹配对应请求标识符之间添加得
        => 只对当前这个路由表生效
        => router.use(函数)
      3. 路由应用级中间件 req, res, next
        => 书写在路由表中
        => 再匹配到指定路径标识符以后, 事件处理函数事件
        => 只对匹配到得该路由标识符生效
        => router.get('路径标识符', 中间件函数, 路由处理函数)
      4. 全局错误处理中间件
        => 一般书写再服务得最后
        => 一般用来返回最终结果
        => 接收四个参数 err req res next
          -> 当前面右任意一个 next(参数)
        => app.use((err, req, res, next) => {})
*/

const express = require('express')
const cookieParser = require('cookie-parser')
const bodyParser = require('body-parser')
const router = express.Router()

// 可以接收第三个参数, 叫做 next
router.get('/a', (req, res) => {
  // 没有让你继续向后走
  // 也没有让你回到客户端

  // 表示本次服务得路到此结束, 返回客户端
  // res.send('hello world')
})
router.get('/b', (req, res, next) => {
  // 再 res 里面设置了一条 cookie
  // 将来组装响应报文得时候, 就会组装上
  res.cookie('a', 1000)

  // 表示路继续向后走
  next()
})
router.get('/c', (req, res) => {
  res.send({
    message: '到此结束',
    username: req.username,
    code: 1
  })
})
router.post('/login', (req, res, next) => {
  // 是否存在

  // res.send({ message: '请完整填写表单', code: 0 })
  next('请完整填写表单')
}, (req, res, next) => {
  // 是否符合格式
  // res.send({ message: '请按照规则填写表单', code: 0 })
  next('请按照规则填写表单')
}, (req, res) => {
  // 去数据库比对
})

// 创建了一个服务
const app = express()
// app 解析完毕, 不会解析 cookie
// app.headers.cookie = 'a=100; b=200; c=300'

// 挂载
// req 里面有了一个 cookies
// res 里面有了一个 cookie()
app.use(cookieParser())

// 解析请求体
app.use(bodyParser())

// 挂载路由
app.use(router)

// 简单得全局中间件
// 所有得请求都得进来
app.use((req, res, next) => {

  req.username = '郭翔'

  next('err')

})






// 添加一个全局错误处理中间件
app.use((err, req, res, next) => {
  // res.send('<h1>404</h1>')`
  // res.send({ message: "本次请求有问题, 请联系管理员", code: 0, username: req.username })
  res.send({
    message: err,
    code: 0
  })
})

// 监听一个端口号
app.listen(8080, () => console.log('running at 8080 !'))
